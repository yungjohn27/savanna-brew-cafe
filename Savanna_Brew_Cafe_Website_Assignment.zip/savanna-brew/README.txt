SAVANNA BREW CAFE WEBSITE
Introduction to Web Development — HTML & CSS Assignment

PROJECT CONTENTS
- index.html: Home page
- about.html: About Us page
- menu.html: Menu and prices
- gallery.html: Responsive image gallery
- contact.html: Contact details, opening hours and reservation form
- css/style.css: Shared external stylesheet
- images/: Local logo and image placeholder assets

HOW TO VIEW
1. Extract the ZIP file.
2. Open the savanna-brew folder.
3. Double-click index.html to open the website in a browser.
4. Use the navigation links to visit all five pages.

NOTES
- The website uses HTML5 and CSS only. It does not use JavaScript or CSS frameworks.
- The image files are locally created illustrative placeholders, which are permitted by the assignment. Replace them with suitable café photographs if available.
- The reservation form demonstrates HTML form fields and browser required-field validation. It does not send or save reservations because no server-side processing is included.
- Google Fonts are linked online; fallback fonts are included in the stylesheet.
- Before submission, validate the HTML and CSS using:
  HTML: https://validator.w3.org/
  CSS: https://jigsaw.w3.org/css-validator/
- W3C validation has not been run in this environment. Record any remaining warnings after validation.

GITHUB SUBMISSION
1. Create a new public repository on GitHub (for example, savanna-brew-cafe).
2. Upload the contents of the savanna-brew folder to the repository root (not the ZIP file alone).
3. Ensure index.html is in the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then save.
6. After GitHub Pages finishes deploying, copy the published website URL and paste it into the assignment textbox. Submit the repository URL instead if your instructor specifically requests the repository link.
